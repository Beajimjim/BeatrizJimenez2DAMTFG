// src/app/pages/supercontrolador/asignacion-personal/asignacion-personal.component.ts
import { Component, Input, OnInit } from '@angular/core';
import { CommonModule }             from '@angular/common';
import { IonicModule, ToastController } from '@ionic/angular';
import { ProyectoService, Tarea }        from 'src/app/services/proyectos.service';
import { PersonalService, Personal }     from 'src/app/services/personal.service';

@Component({
  standalone: true,
  selector: 'app-asignacion-personal',
  imports: [CommonModule, IonicModule],
  templateUrl: './asignacion-personal.component.html',
  styleUrls: ['./asignacion-personal.component.scss']
})
export class AsignacionPersonalComponent implements OnInit {
  @Input() proyectoId!: number;

  tareas: Tarea[]       = [];
  personal: Personal[]  = [];
  selectedTask?: Tarea;
  disponibles: Personal[] = [];

  constructor(
    private proyectoSrv: ProyectoService,
    private personalSrv: PersonalService,
    private toast: ToastController
  ) {}

  ngOnInit() {
    // 1) Cargar tareas pendientes
    this.proyectoSrv.getTareasPorProyecto(this.proyectoId)
      .subscribe(ts => this.tareas = ts.filter(t => t.estado === 'pendiente'));
  
    // 2) Cargar todo el personal y parsear JSONs
    this.personalSrv.listarPorProyecto(this.proyectoId).subscribe(ps => {
      this.personal = ps.map(p => ({
        ...p,
        // parseamos disponibilidad y vacaciones
        disponibilidad: typeof p.disponibilidad === 'string'
          ? JSON.parse(p.disponibilidad)
          : p.disponibilidad,
        vacaciones: typeof p.vacaciones === 'string'
          ? JSON.parse(p.vacaciones)
          : p.vacaciones
      }));
    });
  }

  onSelectTask(t: Tarea) {
    this.selectedTask = t;
  
    // Convertimos el id_perfil de la tarea a número
    const perfilId = typeof t.id_perfil === 'string'
      ? parseInt(t.id_perfil, 10)
      : t.id_perfil;
  
    // Ahora la comparación funcionará
    this.disponibles = this.personal
      .filter(p => p.id_perfil === perfilId);
  }

  async assign(p: Personal) {
    if (!this.selectedTask) return;
  
    // 1) Llamamos correctamente a actualizarTarea(id, payload)
    await this.proyectoSrv
      .actualizarTarea(
        this.selectedTask.id,         // ← primer argumento: id de la tarea
        { id_usuario: p.id_personal } // ← segundo argumento: solo el campo a actualizar
      )
      .toPromise();
  
    // 2) Feedback al usuario
    const toast = await this.toast.create({
      message: `"${this.selectedTask.nombre}" asignada a ${p.nombre}`,
      duration: 2000,
      color: 'success'
    });
    toast.present();
  
    // 3) Refrescar la lista eliminando la tarea asignada
    this.tareas = this.tareas.filter(t => t.id !== this.selectedTask!.id);
    this.selectedTask = undefined;
    this.disponibles = [];
  }
}
