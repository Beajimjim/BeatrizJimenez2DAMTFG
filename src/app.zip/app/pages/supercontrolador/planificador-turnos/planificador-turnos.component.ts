/* ===================================================================
 *  PlanificadorTurnosComponent  (stand-alone)
 * ===================================================================*/
import { CommonModule }  from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { IonicModule }   from '@ionic/angular';

import { FullCalendarModule } from '@fullcalendar/angular';
import resourceTimelinePlugin from '@fullcalendar/resource-timeline';
import interactionPlugin      from '@fullcalendar/interaction';
import { CalendarOptions, EventDropArg }  from '@fullcalendar/core';
import { EventResizeDoneArg} from '@fullcalendar/interaction';

import { TurnosService, Turno } from 'src/app/services/turnos.service';

/* — extras export — */
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { createEvents } from 'ics';

@Component({
  selector: 'app-planificador-turnos',
  standalone: true,
  imports   : [CommonModule, IonicModule, FullCalendarModule],
  templateUrl: './planificador-turnos.component.html',
  styleUrls  : ['./planificador-turnos.component.scss']
})
export class PlanificadorTurnosComponent implements OnInit {

  @Input() proyectoId!: number;

  @ViewChild('cal') calCmp: any;

  recursos: { id: string; title: string }[] = [];
  eventos : any[] = [];

  loading = false;

  calendarOptions: CalendarOptions = {
    plugins            : [resourceTimelinePlugin, interactionPlugin],
    schedulerLicenseKey: 'GPL-My-Project-Is-Open-Source',
    initialView        : 'resourceTimelineWeek',
    slotDuration       : { weeks: 1 },
    editable           : true,
    resourceAreaWidth  : '18%',
    eventDrop          : this.onDrop.bind(this),
    eventResize        : this.onResize.bind(this),
    resources          : () => this.recursos,
    events             : () => this.eventos
  };

  constructor(private turnosSrv: TurnosService) {}

  ngOnInit(): void {
    if (this.proyectoId) this.cargarTurnos();
  }

  /* -------------------------------------------------------------- */
  /*  Cargar turnos                                                 */
  /* -------------------------------------------------------------- */
  cargarTurnos(): void {
    this.loading = true;
    this.turnosSrv.listar(this.proyectoId).subscribe({
      next : tu => {
        this.montarDatos(tu);
        this.loading = false;

        // refresca FullCalendar
        const api = this.calCmp?.getApi?.();
        api?.batchRendering(() => {
          api?.setResources(this.recursos);
          api?.removeAllEvents();
          this.eventos.forEach(e => api?.addEvent(e));
        });
      },
      error: err => { console.error(err); this.loading = false; }
    });
  }

  private montarDatos(turnos: Turno[]): void {
    /* recursos = personas */
    const mapa = new Map<number,string>();
    turnos.forEach(t => {
      if (!mapa.has(t.id_personal))
        mapa.set(t.id_personal, `Pers #${t.id_personal}`);
    });
    this.recursos = Array.from(mapa, ([id,title]) => ({ id: String(id), title }));

    /* eventos = turnos */
    this.eventos = turnos.map(t => ({
      id         : t.id_turno,
      title      : `Tarea ${t.id_tarea} · ${t.horas} h`,
      start      : t.fecha_inicio,
      end        : t.fecha_fin,
      resourceId : String(t.id_personal),
      extendedProps: { horas: t.horas }
    }));
  }

  /* -------------------------------------------------------------- */
  /*  Planificar automático                                         */
  /* -------------------------------------------------------------- */
  planificarAuto(): void {
    if (!confirm('¿Recalcular turnos? Se sobreescribirá la planificación.')) return;
    this.loading = true;
    this.turnosSrv.planificar(this.proyectoId).subscribe({
      next : () => this.cargarTurnos(),
      error: err => { console.error(err); this.loading = false; }
    });
  }

  /* -------------------------------------------------------------- */
  /*  Drag & Drop / Resize                                          */
  /* -------------------------------------------------------------- */
  onDrop(arg: EventDropArg)   { this.persistirCambio(arg.event); }
  onResize(arg: EventResizeDoneArg) { this.persistirCambio(arg.event); }

  private persistirCambio(ev: any) {
    const dto = {
      id_turno     : +ev.id,
      id_personal  : +ev.getResources()[0].id,
      fecha_inicio : ev.startStr.slice(0,10),
      fecha_fin    : ev.endStr.slice(0,10)
    };
    this.turnosSrv.actualizar(dto).subscribe({ error: console.error });
  }

  /* -------------------------------------------------------------- */
  /*  Exportar EXCEL                                                */
  /* -------------------------------------------------------------- */
  exportExcel(): void {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(this.eventos.map(e => ({
      Semana     : e.start.slice(0,10),
      Trabajador : this.recursos.find(r=>r.id===e.resourceId)?.title,
      Tarea      : e.title,
      Horas      : e.extendedProps.horas
    })));
    XLSX.utils.book_append_sheet(wb, ws, 'Turnos');
    XLSX.writeFile(wb, 'turnos.xlsx');
  }

  /* -------------------------------------------------------------- */
  /*  Exportar ICS                                                  */
  /* -------------------------------------------------------------- */
  exportICS(): void {
    const evs = this.eventos.map(e => ({
      title : e.title,
      start : e.start.split('-').map(Number),
      end   : e.end.split('-').map(Number),
      description: `${e.extendedProps.horas} h`,
    }));
    createEvents(evs, (err, ics) => {
      if (err) return console.error(err);
      saveAs(new Blob([ics], {type:'text/calendar'}), 'turnos.ics');
    });
  }
}
