/* =================================================================== *
 * TurnosService
 *  • planificar(idProyecto)  → POST  api/planificar.php
 *  • listar(idProyecto)      → GET   api/turnos.php?id_proyecto=…
 *  • actualizar(turno)       → PUT   api/turnos.php
 * =================================================================== */
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Turno {
  id_turno     : number;
  id_personal  : number;
  id_tarea     : number;
  fecha_inicio : string;   // 'YYYY-MM-DD'
  fecha_fin    : string;
  horas        : number;
}

@Injectable({
  providedIn: 'root'
})
export class TurnosService {

  private api = '/api';                    // ajusta si usas prefijo distinto

  constructor(private http: HttpClient) {}

  /** Planifica automáticamente todas las tareas pendientes */
  planificar(idProyecto: number): Observable<{ num_turnos: number }> {
    return this.http.post<{ num_turnos: number }>(
      `${this.api}/planificar.php`,
      { id_proyecto: idProyecto }
    );
  }

  /** Lista los turnos ya asignados */
  listar(idProyecto: number): Observable<Turno[]> {
    const params = new HttpParams().set('id_proyecto', idProyecto);
    return this.http.get<Turno[]>(`${this.api}/turnos.php`, { params });
  }

  /** Actualiza un turno (drag&drop en el calendario) */
  actualizar(turno: Partial<Turno> & { id_turno: number }): Observable<any> {
    return this.http.put(`${this.api}/turnos.php`, turno);
  }
}
