import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { PlanificadorTurnosComponent } from './planificador-turnos.component';

describe('PlanificadorTurnosComponent', () => {
  let component: PlanificadorTurnosComponent;
  let fixture: ComponentFixture<PlanificadorTurnosComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [PlanificadorTurnosComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PlanificadorTurnosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
